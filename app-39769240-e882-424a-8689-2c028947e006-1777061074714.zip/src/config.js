const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://api.eitherway.ai';

export const PROXY_API = (url) =>
  `${API_BASE_URL}/api/proxy-api?url=${encodeURIComponent(url)}`;

export const DIALECT_PROXY = `${API_BASE_URL}/api/dialect`;

// Jupiter price via dialect proxy (v2 — recommended)
export const JUPITER_PRICE_URL = (mints) =>
  `${DIALECT_PROXY}/price/v2?ids=${mints.join(',')}`;

// CoinGecko for SOL price (includes 24h change)
export const COINGECKO_SOL_PRICE = () =>
  PROXY_API('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd&include_24hr_change=true&include_market_cap=true');

// Local backend endpoints (proxied through Vite in dev, direct in backend pod)
export const LOCAL_RPC = '/api/rpc';
export const LOCAL_TOKEN_LIST = '/api/token-list';
export const LOCAL_PRICE = (ids) => `/api/price?ids=${encodeURIComponent(ids.join(','))}`;

// SOL native mint address
export const SOL_MINT = 'So11111111111111111111111111111111111111112';
export const TOKEN_PROGRAM_ID = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA';
