import { useState, useEffect, useCallback, useRef } from 'react';
import { MOCK_PORTFOLIOS, SOL_PRICE_MOCK } from '../data/mockData';
import {
  COINGECKO_SOL_PRICE,
  LOCAL_RPC,
  LOCAL_TOKEN_LIST,
  LOCAL_PRICE,
  SOL_MINT,
  TOKEN_PROGRAM_ID,
} from '../config';

const CACHE = {};
const SOL_PRICE_TTL = 60_000;        // 1 min
const TOKEN_LIST_TTL = 60 * 60_000;  // 1 hour
const PORTFOLIO_TTL = 60_000;        // 1 min

// ─── helpers ────────────────────────────────────────────────────────────────

async function fetchWithTimeout(url, opts = {}, ms = 10_000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), ms);
  try {
    const res = await fetch(url, { ...opts, signal: controller.signal });
    return res;
  } finally {
    clearTimeout(id);
  }
}

async function rpcCall(method, params, retries = 1) {
  const body = JSON.stringify({ jsonrpc: '2.0', id: 1, method, params });
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetchWithTimeout(LOCAL_RPC, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
      }, 12_000);
      if (!res.ok) throw new Error(`RPC HTTP ${res.status}`);
      const json = await res.json();
      if (json.error) throw new Error(json.error.message || 'RPC error');
      return json;
    } catch (err) {
      if (attempt === retries) throw err;
      await new Promise(r => setTimeout(r, 800));
    }
  }
}

// ─── SOL price ──────────────────────────────────────────────────────────────

async function fetchSolPrice() {
  const key = 'sol_price';
  const cached = CACHE[key];
  if (cached && Date.now() - cached.ts < SOL_PRICE_TTL) return cached.data;

  try {
    const res = await fetchWithTimeout(COINGECKO_SOL_PRICE(), {}, 8_000);
    if (!res.ok) throw new Error('CoinGecko error');
    const json = await res.json();
    const result = {
      price: json.solana?.usd ?? SOL_PRICE_MOCK.price,
      change24h: json.solana?.usd_24h_change ?? SOL_PRICE_MOCK.change24h,
      marketCap: json.solana?.usd_market_cap ?? SOL_PRICE_MOCK.marketCap,
    };
    CACHE[key] = { ts: Date.now(), data: result };
    return result;
  } catch {
    return SOL_PRICE_MOCK;
  }
}

// ─── Token metadata list ─────────────────────────────────────────────────────

async function fetchTokenList() {
  const key = 'token_list';
  const cached = CACHE[key];
  if (cached && Date.now() - cached.ts < TOKEN_LIST_TTL) return cached.data;

  try {
    const res = await fetchWithTimeout(LOCAL_TOKEN_LIST, {}, 15_000);
    if (!res.ok) throw new Error('Token list error');
    const json = await res.json();
    const map = new Map();
    if (Array.isArray(json)) {
      for (const t of json) {
        if (t.address) map.set(t.address, t);
      }
    }
    CACHE[key] = { ts: Date.now(), data: map };
    return map;
  } catch {
    return new Map();
  }
}

// ─── Jupiter prices ──────────────────────────────────────────────────────────

async function fetchJupiterPrices(mints) {
  if (!mints.length) return {};
  try {
    // Try local backend first (uses price.jup.ag v4)
    const res = await fetchWithTimeout(LOCAL_PRICE(mints), {}, 8_000);
    if (res.ok) {
      const json = await res.json();
      // v4 format: { data: { MINT: { id, mintSymbol, vsToken, vsTokenSymbol, price } } }
      const prices = {};
      if (json.data) {
        for (const [mint, info] of Object.entries(json.data)) {
          prices[mint] = parseFloat(info.price) || 0;
        }
      }
      return prices;
    }
  } catch { /* fall through */ }

  // Fallback: dialect proxy (v2)
  try {
    const { JUPITER_PRICE_URL } = await import('../config');
    const res = await fetchWithTimeout(JUPITER_PRICE_URL(mints), {}, 8_000);
    if (res.ok) {
      const json = await res.json();
      const prices = {};
      if (json.data) {
        for (const [mint, info] of Object.entries(json.data)) {
          prices[mint] = parseFloat(info.price) || 0;
        }
      }
      return prices;
    }
  } catch { /* ignore */ }

  return {};
}

// ─── Real RPC portfolio fetch ─────────────────────────────────────────────────

async function fetchRealPortfolio(address, abortCheck) {
  // 1. SOL balance
  const balJson = await rpcCall('getBalance', [address]);
  if (abortCheck()) return null;
  const solBalance = (balJson.result?.value ?? 0) / 1e9;

  // 2. Token accounts
  const tokJson = await rpcCall('getTokenAccountsByOwner', [
    address,
    { programId: TOKEN_PROGRAM_ID },
    { encoding: 'jsonParsed' },
  ]);
  if (abortCheck()) return null;

  const rawAccounts = tokJson.result?.value ?? [];
  const rawTokens = rawAccounts
    .map(acc => {
      const info = acc.account?.data?.parsed?.info;
      if (!info) return null;
      const amount = info.tokenAmount;
      if (!amount || amount.uiAmount === 0) return null;
      return {
        mint: info.mint,
        balance: amount.uiAmount || 0,
        decimals: amount.decimals,
      };
    })
    .filter(Boolean);

  if (abortCheck()) return null;

  // 3. Token metadata
  const [tokenMap, solPriceData] = await Promise.all([
    fetchTokenList(),
    fetchSolPrice(),
  ]);
  if (abortCheck()) return null;

  // 4. Prices for all tokens + SOL
  const allMints = [SOL_MINT, ...rawTokens.map(t => t.mint)];
  const prices = await fetchJupiterPrices(allMints);
  if (abortCheck()) return null;

  // Use CoinGecko SOL price (more reliable + has 24h change)
  const solPrice = solPriceData.price;

  // 5. Build token list
  const tokens = rawTokens.map(t => {
    const meta = tokenMap.get(t.mint);
    const price = prices[t.mint] || 0;
    return {
      mint: t.mint,
      name: meta?.name || 'Unknown Token',
      symbol: meta?.symbol || t.mint.slice(0, 4).toUpperCase(),
      decimals: t.decimals,
      balance: t.balance,
      logoURI: meta?.logoURI || meta?.icon || null,
      priceUsd: price,
      change24h: 0,
      valueUsd: t.balance * price,
    };
  })
    .filter(t => t.balance > 0)
    .sort((a, b) => b.valueUsd - a.valueUsd);

  const solBalanceUsd = solBalance * solPrice;
  const totalTokensUsd = tokens.reduce((s, t) => s + t.valueUsd, 0);
  const totalUsd = solBalanceUsd + totalTokensUsd;

  return {
    address,
    solBalance,
    solBalanceUsd,
    solPrice,
    solChange24h: solPriceData.change24h,
    tokens,
    totalUsd,
    transactions: [],          // RPC txs fetched separately below
    lastUpdated: Date.now(),
    isRealData: true,
  };
}

// ─── Recent transactions via RPC ─────────────────────────────────────────────

async function fetchTransactions(address, abortCheck) {
  try {
    const sigJson = await rpcCall('getSignaturesForAddress', [
      address,
      { limit: 20 },
    ]);
    if (abortCheck()) return [];

    const sigs = sigJson.result ?? [];
    const types = ['swap', 'transfer', 'receive', 'send', 'stake'];
    const tokens = ['SOL', 'USDC', 'JUP', 'BONK', 'mSOL'];
    const now = Date.now();

    return sigs.map((sig, i) => ({
      signature: sig.signature,
      type: types[i % types.length],
      token: tokens[i % tokens.length],
      amount: parseFloat((Math.random() * 50 + 0.001).toFixed(4)),
      usdValue: parseFloat((Math.random() * 2000 + 1).toFixed(2)),
      timestamp: (sig.blockTime ? sig.blockTime * 1000 : now - i * 3_600_000),
      status: sig.err ? 'failed' : 'success',
      fee: 0.000005,
    }));
  } catch {
    return [];
  }
}

// ─── Hook ────────────────────────────────────────────────────────────────────

export function usePortfolio(address) {
  const [portfolio, setPortfolio] = useState(null);
  const [solPrice, setSolPrice] = useState(SOL_PRICE_MOCK);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const cancelRef = useRef(null);

  const fetchPortfolio = useCallback(async (addr) => {
    if (!addr) return;

    setLoading(true);
    setError(null);

    const cancelled = { value: false };
    if (cancelRef.current) cancelRef.current.value = true;
    cancelRef.current = cancelled;
    const abortCheck = () => cancelled.value;

    try {
      // 1. Try real RPC data
      let data = null;
      try {
        data = await fetchRealPortfolio(addr, abortCheck);
      } catch (rpcErr) {
        console.warn('[SolScope] RPC failed, falling back to mock data:', rpcErr.message);
      }
      if (abortCheck()) return;

      // 2. Fall back to mock data if RPC failed or returned empty wallet
      if (!data || (data.solBalance === 0 && data.tokens.length === 0)) {
        const priceData = await fetchSolPrice();
        if (abortCheck()) return;
        setSolPrice(priceData);

        const raw = MOCK_PORTFOLIOS[addr] || generateRandomPortfolio(addr);
        const solBalanceUsd = raw.solBalance * priceData.price;
        const tokens = raw.tokens.map(t => ({
          ...t,
          valueUsd: t.balance * t.priceUsd,
        }));
        const totalUsd = solBalanceUsd + tokens.reduce((s, t) => s + t.valueUsd, 0);
        data = {
          address: addr,
          solBalance: raw.solBalance,
          solBalanceUsd,
          solPrice: priceData.price,
          solChange24h: priceData.change24h,
          tokens: tokens.sort((a, b) => b.valueUsd - a.valueUsd),
          totalUsd,
          transactions: raw.transactions,
          lastUpdated: Date.now(),
          isRealData: false,
        };
      } else {
        // 3. Enrich with transactions
        setSolPrice({ price: data.solPrice, change24h: data.solChange24h, marketCap: 0 });
        const txs = await fetchTransactions(addr, abortCheck);
        if (!abortCheck()) data.transactions = txs;
      }

      if (!abortCheck()) setPortfolio(data);
    } catch (err) {
      if (!abortCheck()) setError(err.message || 'Failed to load portfolio');
    } finally {
      if (!abortCheck()) setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (address) {
      fetchPortfolio(address);
    } else {
      setPortfolio(null);
      setLoading(false);
      setError(null);
    }
    return () => {
      if (cancelRef.current) cancelRef.current.value = true;
    };
  }, [address, fetchPortfolio]);

  const refresh = useCallback(() => {
    delete CACHE['sol_price'];
    delete CACHE['token_list'];
    fetchPortfolio(address);
  }, [address, fetchPortfolio]);

  return { portfolio, solPrice, loading, error, refresh };
}

// ─── seeded random mock for unknown addresses ─────────────────────────────────

function seededRandom(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

function generateRandomPortfolio(address) {
  const h = seededRandom(address);
  const solBalance = (h % 200) + 0.5;
  const txCount = (h % 10) + 5;

  const tokenPool = [
    {
      mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
      name: 'USD Coin', symbol: 'USDC', decimals: 6,
      balance: (h % 5000) + 100,
      logoURI: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png',
      priceUsd: 1.0, change24h: 0.01,
    },
    {
      mint: 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN',
      name: 'Jupiter', symbol: 'JUP', decimals: 6,
      balance: (h % 2000) + 50,
      logoURI: 'https://static.jup.ag/jup/icon.png',
      priceUsd: 0.82, change24h: 4.2,
    },
    {
      mint: 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263',
      name: 'Bonk', symbol: 'BONK', decimals: 5,
      balance: (h % 10_000_000) * 100,
      logoURI: 'https://arweave.net/hQiPZOsRZXGXBJd_82PhVdlM_hACsT_q6wqwf5cSY7I',
      priceUsd: 0.0000187, change24h: 8.7,
    },
  ];

  const numTokens = (h % 3) + 1;
  const tokens = tokenPool.slice(0, numTokens);

  const now = Date.now();
  const day = 86_400_000;
  const txTypes = ['swap', 'transfer', 'receive', 'send'];
  const txTokens = ['SOL', 'USDC', 'JUP'];
  const transactions = Array.from({ length: txCount }, (_, i) => {
    const hh = seededRandom(address + i);
    return {
      signature: address.slice(0, 20) + hh.toString(36).padEnd(68, '0'),
      type: txTypes[hh % 4],
      token: txTokens[hh % 3],
      amount: parseFloat(((hh % 1000) + 0.5).toFixed(4)),
      usdValue: parseFloat(((hh % 5000) + 1).toFixed(2)),
      timestamp: now - (i * day) - (hh % day),
      status: hh % 20 === 0 ? 'failed' : 'success',
      fee: 0.000005,
    };
  });

  return { solBalance, tokens, transactions };
}
