import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react({ jsxRuntime: 'automatic' })],
  server: {
    proxy: {
      '/api/rpc': 'http://localhost:3001',
      '/api/token-list': 'http://localhost:3001',
      '/api/price': 'http://localhost:3001',
    },
    watch: {
      usePolling: true,
      interval: 1000,
    },
    cors: true,
    allowedHosts: true,
  },
})
